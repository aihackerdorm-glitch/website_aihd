
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-pages.mts
import { createClient } from "@supabase/supabase-js";
async function verifyAdmin(req) {
  const headerPwd = req.headers.get("x-admin-password");
  const adminPwd = process.env.ADMIN_PASSWORD || process.env.VITE_ADMIN_PASSWORD || "";
  if (adminPwd && headerPwd && headerPwd === adminPwd) return true;
  return new Response("Unauthorized", { status: 401 });
}
var admin_pages_default = async (req, _context) => {
  const authRes = await verifyAdmin(req);
  if (authRes instanceof Response) return authRes;
  const urlEnv = process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!urlEnv || !serviceKey) {
    return new Response("Server misconfigured: missing SUPABASE env vars", { status: 500 });
  }
  const supabase = createClient(urlEnv, serviceKey);
  const url = new URL(req.url);
  const slug = url.pathname.split("/").pop();
  if (req.method === "GET") {
    const { data, error } = await supabase.from("site_pages").select("slug,title,visible").order("slug", { ascending: true });
    if (error) return new Response(error.message, { status: 500 });
    return Response.json(data || []);
  }
  if (req.method === "PATCH" && slug) {
    const body = await req.json();
    const { visible, title } = body;
    if (typeof visible !== "boolean" && typeof title !== "string") {
      return new Response("No changes provided", { status: 400 });
    }
    const update = {};
    if (typeof visible === "boolean") update.visible = visible;
    if (typeof title === "string") update.title = title;
    const { error } = await supabase.from("site_pages").update(update).eq("slug", slug);
    if (error) return new Response(error.message, { status: 500 });
    const { data } = await supabase.from("site_pages").select("slug,title,visible").eq("slug", slug).single();
    return Response.json(data);
  }
  return new Response("Method Not Allowed", { status: 405 });
};
var config = {
  path: [
    "/api/admin/pages",
    "/api/admin/pages/:slug"
  ]
};
export {
  config,
  admin_pages_default as default
};
