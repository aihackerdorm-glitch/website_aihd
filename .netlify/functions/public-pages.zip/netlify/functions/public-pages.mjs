
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/public-pages.mts
import { createClient } from "@supabase/supabase-js";
var public_pages_default = async (req) => {
  if (req.method !== "GET") {
    return new Response("Method Not Allowed", { status: 405 });
  }
  const urlEnv = process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!urlEnv || !serviceKey) {
    return new Response("Server misconfigured: missing SUPABASE env vars", { status: 500 });
  }
  const supabase = createClient(urlEnv, serviceKey);
  const { data, error } = await supabase.from("site_pages").select("slug,title,visible").order("slug", { ascending: true });
  if (error) return new Response(error.message, { status: 500 });
  return Response.json(data || []);
};
var config = {
  path: [
    "/api/public/pages"
  ]
};
export {
  config,
  public_pages_default as default
};
