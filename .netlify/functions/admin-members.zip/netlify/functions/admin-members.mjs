
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/admin-members.mts
import { createClient } from "@supabase/supabase-js";
async function verifyAdmin(req) {
  const headerPwd = req.headers.get("x-admin-password");
  const adminPwd = process.env.ADMIN_PASSWORD || process.env.VITE_ADMIN_PASSWORD || "";
  if (adminPwd && headerPwd && headerPwd === adminPwd) return true;
  return new Response("Unauthorized", { status: 401 });
}
var admin_members_default = async (req, _context) => {
  const authRes = await verifyAdmin(req);
  if (authRes instanceof Response) return authRes;
  const urlEnv = process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!urlEnv || !serviceKey) {
    return new Response("Server misconfigured: missing SUPABASE env vars", { status: 500 });
  }
  const supabase = createClient(urlEnv, serviceKey);
  const url = new URL(req.url);
  const id = url.pathname.split("/").pop();
  if (req.method === "GET") {
    const { data: memberships, error: mErr } = await supabase.from("memberships").select("id,user_id,role,joined_at").order("joined_at", { ascending: false });
    if (mErr) return new Response(mErr.message, { status: 500 });
    const userIds = (memberships || []).map((m) => m.user_id);
    let profilesByUser = {};
    if (userIds.length) {
      const { data: profiles, error: pErr } = await supabase.from("profiles").select("user_id,name,visibility").in("user_id", userIds);
      if (pErr) return new Response(pErr.message, { status: 500 });
      for (const p of profiles || []) profilesByUser[p.user_id] = p;
    }
    const result = (memberships || []).map((m) => ({
      ...m,
      profile: profilesByUser[m.user_id] || null
    }));
    return Response.json(result);
  }
  if (req.method === "PATCH" && id) {
    const body = await req.json();
    const { role, visibility } = body;
    if (role) {
      const { error: rErr } = await supabase.from("memberships").update({ role }).eq("user_id", id);
      if (rErr) return new Response(rErr.message, { status: 500 });
    }
    if (typeof visibility === "boolean") {
      const { error: vErr } = await supabase.from("profiles").update({ visibility }).eq("user_id", id);
      if (vErr) return new Response(vErr.message, { status: 500 });
    }
    const { data: membership, error: gErr } = await supabase.from("memberships").select("id,user_id,role,joined_at").eq("user_id", id).single();
    if (gErr) return new Response(gErr.message, { status: 500 });
    const { data: profile } = await supabase.from("profiles").select("user_id,name,visibility").eq("user_id", id).single();
    return Response.json({ ...membership, profile: profile || null });
  }
  return new Response("Method Not Allowed", { status: 405 });
};
var config = {
  path: [
    "/api/admin/members",
    "/api/admin/members/:id"
  ]
};
export {
  config,
  admin_members_default as default
};
